fn = 'cau2'

fi = open(f'./{fn}.inp', 'r')
fo = open(f'./{fn}.out', 'w')

for _ in range(3):
    s1 = fi.readline().rstrip('\n')
    s2 = fi.readline().rstrip('\n')

    s1_set = set(s1)
    s2_set = set(s2)

    fo.write('YES') if s1_set == s2_set else fo.write('NO')

    if _ != 2: fo.write('\n')