fn = 'cau3'

fi = open(f'./{fn}.inp', 'r')
fo = open(f'./{fn}.out', 'w')

s = fi.readline()

score = 0
count = 1

for chr in s:
    if chr == 'D': 
        score += count
        count += 0.5
    elif chr == 'S':
        count = 1

fo.write(f'{score:.1f}')