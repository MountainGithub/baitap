fn = 'cau4'

fi = open(f'./{fn}.inp', 'r')
fo = open(f'./{fn}.out', 'w')

h = list(map(int, fi.readline().split()))
s = fi.readline()

maxh = 0
for chr in s:
    maxh = max(maxh, h[ord(chr)-97])

fo.write(f'{maxh*len(s)}')