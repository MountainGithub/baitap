fn = 'cau1'

fi = open(f'./{fn}.inp', 'r')
fo = open(f'./{fn}.out', 'w')

s1 = fi.readline().rstrip('\n').lower()
s2 = fi.readline().lower()

s = ''
for char in s1:
    if char in s2 and char not in s:
        s += char

fo.write(s.upper())