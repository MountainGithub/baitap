fn = 'cau5'

fi = open(f'./{fn}.inp', 'r')
fo = open(f'./{fn}.out', 'w')

s = fi.readline()

while s.find('{') != -1:
    start = s.rfind('{') # tim { o vi tri xa nhat
    end = s.find('}') # tim } o vi tri gan nhat

    s = s[:start] + s[end+1:]

fo.write(s)